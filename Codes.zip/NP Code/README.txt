-- Global Thresholding --
MATLAB Mobile (can also be run on desktop)
Smartphone_norovirus3.m
This can also be run on desktop and is the fastest MATLAB method for quick analysis and troubleshooting, if needed. 

MATLAB GUI
selectfiles.m
selectfiles.fig
Must be run on desktop, GUI provides user interface to select multiple photos and analyze base on mean intensity and max intensity. 

-- Adaptive Thresholding --
NorovirusMacro.ijm
Macro that speeds up the pipeline for selecting photos, performing the BENSEN adaptive local thresholding with radius = 1, Analyze Particles, and then saves the list to .csv file
The list of particles can then be opened in excel to perform size thresholding and calculate immunoaglutinated particle area.