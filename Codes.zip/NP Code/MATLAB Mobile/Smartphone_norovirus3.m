%Manually input photos to be analyzed
FileName = {'IMG_8437.TIF','IMG_8438.TIF','IMG_8439.TIF','IMG_8440.TIF'};
sum_pixels = 0;
%Loop through each photo and analyze for particles
for i = 1:length(FileName)
    count{i} = length(FileName);
    image = imread(FileName{i});
    %Find image #i
    
    rgbImage = image(:,:,1:3);
    figure(i), imshow(rgbImage)
    %green = image(:,:,2) + image(:,:,1); % red plus 200/235 or 254
    green = image(:,:,2); %Red 50/70
    intensity1 = max(green(:));
    threshold = graythresh(green);
    if intensity1 > 50
        intensity2_auto = 120/255;

   
    end
    g_b=im2bw(green,intensity2_auto);
    figure(i), imshow(g_b)
    g_b= bwareafilt(g_b,[42,100]);
    figure(i), imshow(g_b)
    stats = regionprops(g_b, 'Area');
    A = [stats.Area];
    B = find((A) >= 42);
    %idx = find([stats.Area] >= 30);
    %sum_pixels = sum_pixels + sum(idx(:));
    circle_area = A(B);
    sum_pixels = sum_pixels + sum(circle_area);
    i = i + 1;
    
    
end
%Output total average pixel count
%Note: Based on previous results, using Mean Analysis, if pixel count is larger than ~500, virus is present in the sample tested.
average = sum_pixels/length(FileName)
total = sum_pixels
if total > 500
    result = 'positive'
else
    result = 'negative'
end

