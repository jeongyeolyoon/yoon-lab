
function varargout = selectfiles(varargin)
% SELECTFILES MATLAB code for selectfiles.fig
%      SELECTFILES, by itself, creates a new SELECTFILES or raises the existing
%      singleton*.
%
%      H = SELECTFILES returns the handle to a new SELECTFILES or the handle to
%      the existing singleton*.
%
%      SELECTFILES('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SELECTFILES.M with the given input arguments.
%
%      SELECTFILES('Property','Value',...) creates a new SELECTFILES or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before selectfiles_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to selectfiles_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help selectfiles

% Last Modified by GUIDE v2.5 22-Jun-2017 14:26:55

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @selectfiles_OpeningFcn, ...
                   'gui_OutputFcn',  @selectfiles_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
end
% End initialization code - DO NOT EDIT

% --- Executes just before selectfiles is made visible.
function selectfiles_OpeningFcn(hObject, ~, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to selectfiles (see VARARGIN)

% Choose default command line output for selectfiles
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
% UIWAIT makes selectfiles wait for user response (see UIRESUME)
% uiwait(handles.figure1);
end

% --- Outputs from this function are returned to the command line.
function varargout = selectfiles_OutputFcn(hObject, ~, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%Initialize some values
handles.samples = 0;
handles.Titles = {'Sample Name:', 'Images Analyzed:', 'Avg Pixel Count:'};
set(handles.uitable3, 'Data', handles.Titles);
guidata(hObject, handles);
end

% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, ~, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[FileName, PathName] = uigetfile({'*.jpg;*.tif;*.png'},'Please Select Yo Image', 'MultiSelect', 'on');

handles.FileName = FileName;
handles.PathName = PathName;
handles.samples = handles.samples + 1;
guidata(hObject,handles);
end

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)  %MEAN ANALYSIS

FileName = handles.FileName;
PathName = handles.PathName;

%Analyze Picture
sum_pixels = 0;

for i=1:length(FileName)

    count{i} = length(FileName);
    %Find image #i
    image = imread([PathName, FileName{i}]);
    rgbImage = image(:,:,1:3);
    figure(i), imshow(rgbImage)
    
    %Crop to pre-defined ellipse size
    user_defined_ellipse = imellipse(gca, [450 1300 900 900]); % creates user defined ellipse object.
    xyCoordinate = wait(user_defined_ellipse);
    xyCoordinate = user_defined_ellipse.getPosition();
    image = imcrop(rgbImage,xyCoordinate);
    
    %Isolate green channel
    green = image(:,:,2) + image(:,:,1); % red plus green
   
%     blackPixelImage = sum(rgbImage, 3)<=50;
%     numBlackPixels = sum(blackPixelImage(:));
%     allPixels = 9144576;
% 
%    % intensity1 = mean(green(:)-numBlackPixels); % average of image which is choosen
%     intensity1 = sum(green(:))/(allPixels-numBlackPixels);
    %imshow(green);
    intensity1 = mean(green(:));
    intensity{i} = intensity1;
    %Normalize intensity, apply threshold, binarize
    if intensity1>100
        intensity1 = intensity1 + 50;
    else
        intensity1 = intensity1 + 50;
    end
    
    intensity2_mean = intensity1/255
    
    g_b{i}=im2bw(green,intensity2_mean);
    
    stats = regionprops(g_b{i}, 'Area')
    A = [stats.Area];
    B = find((A) >= 30);
    circle_area{i} = A(B);
    
    %Find immunoaglutinated particles
    Rmin = 3;Rmax = 10;
    [centersBright, radiiBright] = imfindcircles(g_b{i},[Rmin, Rmax],'ObjectPolarity','bright','sensitivity',0.9);
    masks{i} = [centersBright, radiiBright];
   % circle_area{i} = radiiBright.^2.*pi;
    sum_pixels = sum_pixels + sum(circle_area{i});
    
    i = i + 1;
end


%     %Crop to pre-defined ellipse size
%     user_defined_ellipse = imellipse(gca, [450 1600 1200 1200]); % creates user defined ellipse object.
%     xyCoordinate = wait(user_defined_ellipse);
%     xyCoordinate = user_defined_ellipse.getPosition();
%     image = imcrop(rgbImage,xyCoordinate);
%     
%     %Isolate green channel
%     green = image(:,:,2); % + image(:,:,3);
%     intensity1 = max(green(:));
%     intensity{i} = intensity1
% 
%     %Normalize intensity, apply threshold, binarize
%     if intensity1>200
%         intensity1 = intensity1 - 30;
%     else
%         intensity1 = intensity1 - 20;
%     end
%     
%     I = intensity1/255;
%     g_b{i}=imbinarize(green, I);
%     
%     %Find immunoaglutinated particles
%     Rmin = 4;Rmax = 10;
%     [centersBright, radiiBright] = imfindcircles(g_b{i},[Rmin, Rmax],'ObjectPolarity','bright','Sensitivity', 0.9);
%     masks{i} = [centersBright, radiiBright];
%     circle_area{i} = radiiBright.^2.*pi;
%     sum_pixels = sum_pixels + sum(circle_area{i});
%     
%     i = i + 1;
% end

handles.circle_area = circle_area;
handles.intensity = intensity;
handles.masks = masks;
handles.sum_pixels = sum_pixels;
handles.g_b = g_b;
guidata(hObject,handles);

CreateFcn(hObject, eventdata, handles);
end

% --- Executes during object creation, after setting all properties.
function CreateFcn(hObject, eventdata, handles)

FileName = handles.FileName;
circle_area = handles.circle_area;
intensity = handles.intensity;
masks = handles.masks;
sum_pixels = handles.sum_pixels;
g_b = handles.g_b;

%Prompt name of results & text file
handles.new_file = inputdlg('Input New File Name: ', 'New File'); %User input
handles.OldVals = get(handles.uitable3, 'Data');
guidata(hObject, handles)
uitable3_CreateFcn(hObject, eventdata, handles)

%Write (final) Results to text file
write_file = fopen([char(handles.new_file) '.txt'], 'w');
fprintf(write_file, 'Images Analyzed: %f', length(FileName));
fprintf(write_file, '\nTotal Sample''s Average Pixel Count: %f\n', sum_pixels/length(FileName));
handles.channel_data = [char(handles.new_file) '.txt', length(FileName), sum_pixels/length(FileName)]
guidata(hObject, handles);

%Show Masks
for i=1:length(FileName)
    %Show masks
    figure(i), imshow(g_b{i}), title(['Immunoagglutinated Particles: ' FileName{i}] );
    
    if masks{i} > 0
        centerBx = masks{i}(:,1);
        centerBy = masks{i}(:,2);
        radiiB = masks{i}(:,3);
        centerB = [centerBx centerBy];
        viscircles(centerB, radiiB,'Color','r');
    end
    
    %Write (individual) results to file
    fprintf(write_file,'\nImage Name: %s',FileName{i});
    fprintf(write_file,'\nIntensity: %f',intensity{i});
    fprintf(write_file,'\nArea:');
    fprintf(write_file,'\n%f',circle_area{i}); %limitedArea);
    fprintf(write_file,'\nTotal Area: %f\n',sum(circle_area{i})); %total_area)
end

fclose(write_file);
end

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, ~, handles) %FOLDER BUTTON
[FileName,~] = uigetfile({'*.txt'},'Please Select Data File');
handles.open_file = FileName;
winopen(FileName);
guidata(hObject, handles);
end

% --- Executes during object creation, after setting all properties.
function uitable3_CreateFcn(hObject, ~, handles)

handles.NewVals = [handles.new_file, length(handles.FileName), handles.sum_pixels/length(handles.FileName)];
handles.NewVals = [handles.OldVals; handles.NewVals];
handles.samples = handles.samples + 1;
guidata(hObject,handles)

%xlswrite([char(handles.new_file) '.xlsx'], handles.NewVals);
%readtable([char(handles.new_file) '.xlsx']);
set(handles.uitable3, 'Data', handles.NewVals);
%guidata(hObject,handles)
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles) %MAX ANALYSIS

FileName = handles.FileName;
PathName = handles.PathName;

%Analyze Picture
sum_pixels = 0;
for i=1:length(FileName)
    count{i} = length(FileName);
    
    %Find image #i
    image = imread([PathName, FileName{i}]);
    rgbImage = image(:,:,1:3);
    figure(i), imshow(rgbImage)
    
    %Crop to pre-defined ellipse size
    user_defined_ellipse = imellipse(gca, [450 1600 1200 1200]); % creates user defined ellipse object.
    xyCoordinate = wait(user_defined_ellipse);
    xyCoordinate = user_defined_ellipse.getPosition();
    image = imcrop(rgbImage,xyCoordinate);
    
    %Isolate red channel  
    
    r_channel = image(:,:,1);
    r_max = max(r_channel(:));
    r = double(r_channel)/double(r_max);
    
    g_channel = image(:,:,1);
    g_max = max(g_channel(:));
    g = double(g_channel)/double(g_max);
    
    image = (r+g)/2;
    g_b{i} = im2bw(image,160/255);
    
    intensity1 = 160;
    intensity{i} = intensity1;
    %Normalize intensity, apply threshold, binarize
%     if intensity1 >= 100
%         intensity2 = (double(intensity1)*0.3)/255;
%     elseif intensity1 >= 30
%         intensity2 = (double(intensity1)*0.7)/255;
%     else
%         intensity2 = (double(intensity1)*0.45)/255;
%     end


    
    %Binarize
    %g_b{i}=im2bw(green,intensity2);
    
    stats = regionprops(g_b{i}, 'Area')
    A = [stats.Area];
    B = find(A >= 10);
    circle_area{i} = A(B);
    
    %circle_area{i} = find([stats.Area])
    %circle_area{i} = sum(idx(:));
    %sum_pixels = sum_pixels + sum(idx(:))

    %Find immunoaglutinated particles
    Rmin = 3;Rmax = 10;
    [centersBright, radiiBright] = imfindcircles(g_b{i},[Rmin, Rmax],'ObjectPolarity','bright','sensitivity',0.9);
    masks{i} = [centersBright, radiiBright];
    %circle_area{i} = radiiBright.^2.*pi;
    
    %if circle_area{i} >= 10
    sum_pixels = sum_pixels + sum(circle_area{i});
 
    
      
    i = i + 1;

end

handles.circle_area = circle_area;
handles.intensity = intensity;
handles.masks = masks;
handles.sum_pixels = sum_pixels;
handles.g_b = g_b;
guidata(hObject,handles);

CreateFcn(hObject, eventdata, handles);
end


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over pushbutton4.
function pushbutton4_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
end


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles) %MAX AUTO
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
FileName = handles.FileName;
PathName = handles.PathName;

%Analyze Picture
sum_pixels = 0;

for i=1:length(FileName)

    count{i} = length(FileName);
    %Find image #i
    image = imread([PathName, FileName{i}]);
    rgbImage = image(:,:,1:3);
    
    %Isolate green channel
    %green = image(:,:,2) + image(:,:,1); % red plus 
    green = image(:,:,1); % red only 
    
    %Normalize intensity, apply threshold, binarize
    intensity1 = max(green(:));
    intensity{i} = intensity1;
    
  if intensity1 >= 100
        intensity2 = (double(intensity1)*0.3)/255;
    elseif intensity1 >= 30
        intensity2 = (double(intensity1)*0.7)/255;
    elseif (30>intensity1) && (intensity1 >= 20)
        intensity2 = (double(intensity1)*0.45)/255;
    else
        intensity2 = (10)/255;
    end 
    
    %Binarize
    g_b{i}=im2bw(green,intensity2);
    
   % stats = regionprops(g_b{i}, 'Area')
    %idx = find([stats.Area] >= 10)
    %sum_pixels = sum_pixels + sum(idx(:))

    %Find immunoaglutinated particles
    Rmin = 2;Rmax = 10;
    [centersBright, radiiBright] = imfindcircles(g_b{i},[Rmin, Rmax],'ObjectPolarity','bright','sensitivity',0.9);
    masks{i} = [centersBright, radiiBright];
    circle_area{i} = radiiBright.^2.*pi;
    if circle_area{i} >= 20
        sum_pixels = sum_pixels + sum(circle_area{i})
    end
    i = i + 1;

end

handles.circle_area = circle_area;
handles.intensity = intensity;
handles.masks = masks;
handles.sum_pixels = sum_pixels;
handles.g_b = g_b;
guidata(hObject,handles);

CreateFcn(hObject, eventdata, handles);
end
