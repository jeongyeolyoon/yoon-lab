//System Requirements
/Hardware requirements
No non-standard hardware is required for the MATLAB or ImageJ software portion of this protocol. Minimum 2 GB of RAM is required to run MATLAB. SSD is recommended over HDD for running MATLAB, but is not a requirement.

/Software requirements
All software can be run on iOS or Windows. MATLAB mobile can be run on iOS 11, Android 5.1, or later versions. The mobile phone will require wifi connection. Running MATLAB on desktop requires 2.9 GB of HDD space and 508GB for a typical installation. 

/Licensing requirements
ImageJ and its Java source code are freely available to public and does not require a license. MATLAB and MATLAB Mobile require a valid license that is current on MathWorks Software Maintenance Service. 

The MATLAB code was run with version R2019b. ImageJ was run on version 1.80_112 (70MB). MATLAB Mobile was run on version 8.0. 

//Downloading and Installation
ImageJ can be downloaded from https://imagej.nih.gov/ij/download.html. Further instructions can be found at https://imagej.nih.gov/ij/docs/install/windows.html for Windows installations, and there is a link to help for iOS installation and use. 
The installation process takes less than 5 minutes. 

MATLAB can be downloaded from  https://www.mathworks.com/downloads/. In order to activate the installation the user needs to have an active MathWorks license to log in with after installation. 
The installation process can take up to 30 minutes and will require 536 MB of disk space. 

MATLAB Mobile can be downloaded on the smartphone app store, either from the Apple Store or Google Play Store. 
The installation process takes less than 5 minutes. 

//Instructions for use
The MATLAB and MATLAB Mobile code use global values for intensity-based thresholding and for size-based threhsolding. 
All analysis is done by the code, including image processing as well as calculation of average and total pixel counts from the analyzed image/s. 
To run the MATLAB Mobile code on the desktop or on the mobile phone, open the application and load the file Smartphone_norovirus3.m previously downloaded from the Yoon Biosensors Lab github page. 
Add the photos that need to be analyzed to the active file open in MATLAB. Update the image names in the MATLAB code to match the images that need to be analyzed. 
Run the code and record the output values representing the total particle area and average particle size. This value can be compared to a standard curve or can be used for the development of another standard curve.
This code can be run on desktop or on smartphones and is the fast MATLAB method for quick analysis and troubleshooting, if needed.

The MATLAB GUI can only be run on a desktop computer. 
Download selectfiles.m and selectfiles.fig from the Yoon Biosensors Lab github page. Double click on selectfiles.fig to open the GUI. 
Click select files button to load the images to be analyzed. Select either mean or max buttons to analyze the images. The user will need to place the circle over the area to be analyzed. 
Select auto to automatically analyze the reuslts, but this method was not used for official data analysis. 
The MATLAB GUI was not used for official data collection in this paper, but is provided as an interface that can assist users with little to no MATLAB experience. 
For ideal image processing use the MATLAB Mobile code for global threhsolding, and use the ImageJ macro for adaptive thresholding. 

The ImageJ macro is used for adaptive intensity-based thresholding. This macro provides a fast pipeline for selecting photos, performing image processing, and outputting the results to a .csv file. 
Download NorovirusMacro.ijm from the Yoon Biosensors Lab github page. Open the ImageJ application on your desktop computer and open the macro. 
Running the macro automates the process of selecting an image from a file, performing auto-local thresholding using the Bernsen method with radius = 1, and outputting a list of the total particles detected from the resulting binarized image into a .csv file. 
This output needs to then externally be size-thresholded (eg. eliminate all particles with area less than 20 pixels) and then summed and averaged to get the total and average pixel counts of immunoaglutinated particles.

//Demo
All analysis processes should take less than 5 minutes from loading/selecting the images to getting an estimated area of immunoaglutinated particles in the images analyzed. 
Only exceptions to this would be if the global thresholding value for the MATLAB code is not ideal, then the user will need to follow the troubleshooting tips described in the paper to improve the accuracy of the image processing.

The below process uses adaptive thresholding.
Download the two .tif files from Yoon Biosensors Lab github page. Open ImageJ application on your desktop and open the NorovirusMacro.ijm macro. Run the macro and select the DI_capsid.tif file when prompted. 
Open the generated DI_capsid.csv file in Microsoft Excel and sum the particle areas, excluding any particles smaller than 20 pixels. The resulting value should be very small, corresponding to a lack of target virus in the image.
Run the macro again and open the NoV_capsid.tif file. Again, open the generated .csv file in Excel and sum the particles larger than 20 pixels. Compare this value to the value from the DI water image. The NoV capsid values should be significantly larger than the DI water value.

To run the same analysis using MATLAB and global thresholding, open the Smartphone_norovirus3.m file in MATLAB or MATLAB Mobile. Make sure the DI_capsid.tif and NoV_capsid.tif images are in the same active file. 
Change the names in the MATLAB code to say DI_capsid.tif and NoV_capsid.tif. Run the code. The output values will be different to the adaptive thresholding since a different technique has been applied, but will be similar. 
The NoV_capsid image will have a larger particle area than the DI_capsid phto. If the results look incorrect (see protocol paper for troubleshooting image processing), try changing the thresholding values used. 

//Reproduction
Images analyzed to get the figures seen in the protocol are available upon request. Similar results should be seen if the user repeats the same protocol steps described. For instructions on standard curve creation, see the protocol.